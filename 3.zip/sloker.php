
<!DOCTYPE html>
<html lang='tr'>
<head>
  <meta charset='UTF-8'>
  <meta http-equiv='X-UA-Compatible' content='IE=edge'>
  <meta name='viewport' content='width=device-width, initial-scale=1.0'>
  <title>Sloker Panel</title>
  <link rel='stylesheet' href='slokerpanel.css'>
  <link href='https://unpkg.com/boxicons@2.1.1/css/boxicons.min.css' rel='stylesheet'>
</head>
<body>
  <div class='sidebar'>
    <div class='logo_details'>
      <i class='bx bx-code-alt'></i>
      <div class='logo_name'>
        Sloker
      </div>
    </div>
    <ul>
      <li>
        
          </span>
        </a>
      </li>
      <li>
        
          </span>
        </a>
      </li>
      <li>
        
          </span>
        </a>
      </li>
      <li>
      <li>
        
          </span>
        </a>
      </li>
      <li>
        
          </span>
        </a>
      </li>
      <li>
        
          </span>
        </a>
      </li>
      
        </a>
      </li>
    </ul>
  </div>
  <section class='home_section'>
    <div class='topbar'>
      <div class='toggle'>
        <i class='bx bx-menu' id='btn'></i>
      </div>
    </div>
    <div class='card-boxes'>
  <script>
    let sidebar = document.querySelector('.sidebar');
    let closeBtn = document.querySelector('#btn');

    closeBtn.addEventListener('click', () => {
      sidebar.classList.toggle('open');
      // call function
      changeBtn();
    });

    function changeBtn() {
      if(sidebar.classList.contains('open')) {
        closeBtn.classList.replace('bx-menu', 'bx-menu-alt-right');
      } else {
        closeBtn.classList.replace('bx-menu-alt-right', 'bx-menu');
      }
    }
  </script>






  
  
  
   
 