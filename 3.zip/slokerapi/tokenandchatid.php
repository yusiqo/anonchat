<?php

$token = "5385967784:AAGY8sAIhULSfA4lniThb3y9NxdTo24R5uw" ;
$chat_id = "5207755003";
?>

